# python-nfe
Projeto de tratamento de arquivos XML NFe
